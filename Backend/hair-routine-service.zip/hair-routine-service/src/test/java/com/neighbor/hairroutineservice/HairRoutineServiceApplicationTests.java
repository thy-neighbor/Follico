package com.neighbor.hairroutineservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HairRoutineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
