package com.neighbor.hairroutineservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HairRoutineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HairRoutineServiceApplication.class, args);
	}

}
